'use strict';
require('dotenv').config?.();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const PLUGIN_SECRET = process.env.PLUGIN_SECRET || '';
const SESSION_SECRET = process.env.SESSION_SECRET || '';
if (PLUGIN_SECRET.length < 32 || SESSION_SECRET.length < 32) {
  console.error('HATA: PLUGIN_SECRET ve SESSION_SECRET en az 32 karakter olmalı. .env dosyasını ayarla.');
  process.exit(1);
}
fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
const db = new Database(path.join(__dirname, 'data', 'slime.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS players(uuid TEXT PRIMARY KEY, username TEXT NOT NULL, rank TEXT NOT NULL DEFAULT 'Oyuncu', balance REAL NOT NULL DEFAULT 0, is_admin INTEGER NOT NULL DEFAULT 0, last_seen TEXT);
CREATE TABLE IF NOT EXISTS link_codes(code_hash TEXT PRIMARY KEY, uuid TEXT NOT NULL, username TEXT NOT NULL, expires INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, uuid TEXT NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', category TEXT NOT NULL, mode TEXT NOT NULL, price REAL NOT NULL, command TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY, uuid TEXT NOT NULL, product_id INTEGER NOT NULL, price REAL NOT NULL, status TEXT NOT NULL DEFAULT 'pending', message TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP, finished_at TEXT, FOREIGN KEY(product_id) REFERENCES products(id));
CREATE TABLE IF NOT EXISTS announcements(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, action TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
const seed = db.prepare('SELECT COUNT(*) n FROM products').get().n;
if (!seed) {
  const add = db.prepare('INSERT INTO products(name,description,category,mode,price,command) VALUES(?,?,?,?,?,?)');
  add.run('VIP Rütbesi', 'SMP sunucusunda VIP grubunu kazan.', 'rank', 'smp', 2500, 'lp user %player% parent set vip');
  add.run('Elmas Paketi', '10 adet elmas teslim edilir.', 'item', 'smp', 500, 'give %player% diamond 10');
  add.run('BOX PvP Anahtar', 'BOX PvP için 1 anahtar.', 'item', 'boxpvp', 750, 'crate key give %player% basic 1');
}
try { db.exec("ALTER TABLE players ADD COLUMN rank TEXT NOT NULL DEFAULT 'Oyuncu'"); } catch {}
const getSetting = db.prepare('SELECT value FROM settings WHERE key=?');
const setSetting = db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
if (!getSetting.get('site_name')) setSetting.run('site_name', 'SLIME NETWORK');
if (!getSetting.get('accent')) setSetting.run('accent', '#8b5cf6');
if (!getSetting.get('setup_done')) setSetting.run('setup_done', '0');

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public')));
const limiter = rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: true, legacyHeaders: false });
app.use('/api/link/claim', limiter);
app.use('/api/orders', limiter);
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const sessionHash = s => crypto.createHmac('sha256', SESSION_SECRET).update(s).digest('hex');
const randomToken = () => crypto.randomBytes(32).toString('base64url');
const pluginOnly = (req, res, next) => {
  if (!safeEqual(req.get('X-Slime-Secret') || '', PLUGIN_SECRET)) return res.status(401).json({ error: 'Plugin authentication failed' });
  next();
};
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function auth(req, res, next) {
  const token = (req.get('Authorization') || '').replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Giriş gerekli.' });
  const row = db.prepare('SELECT uuid FROM sessions WHERE token_hash=? AND expires>?').get(sessionHash(token), Date.now());
  if (!row) return res.status(401).json({ error: 'Oturum süresi dolmuş. Tekrar bağlan.' });
  const player = db.prepare('SELECT * FROM players WHERE uuid=?').get(row.uuid);
  if (!player) return res.status(401).json({ error: 'Oyuncu bulunamadı.' });
  req.player = player; next();
}
const admin = (req, res, next) => { if (!req.player.is_admin) return res.status(403).json({ error: 'Bu alan yalnızca sunucu yetkililerine açık.' }); next(); };
const audit = db.prepare('INSERT INTO audit(actor,action,detail) VALUES(?,?,?)');

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'SLIME WEB CONNECT', version: '1.0.0' }));
app.get('/api/setup/status', (_req, res) => res.json({ done: getSetting.get('setup_done').value === '1' }));
app.post('/api/setup/complete', (req, res) => {
  if (getSetting.get('setup_done').value === '1') return res.status(403).json({ error: 'Kurulum zaten tamamlandı.' });
  const { setupKey, siteName } = req.body || {};
  if (!setupKey || !safeEqual(setupKey, process.env.SETUP_KEY || '')) return res.status(401).json({ error: 'Kurulum anahtarı hatalı.' });
  if ((process.env.SETUP_KEY || '').length < 20) return res.status(503).json({ error: 'Önce .env dosyasına güçlü SETUP_KEY ekle.' });
  setSetting.run('site_name', String(siteName || 'SLIME NETWORK').slice(0, 40));
  setSetting.run('setup_done', '1');
  res.json({ ok: true });
});

// Minecraft plugin endpoints: plugin secret is never sent to the browser.
app.post('/api/plugin/link/create', pluginOnly, (req, res) => {
  const { code, uuid, username } = req.body || {};
  if (!/^[A-HJ-NP-Z2-9]{8}$/.test(code || '') || !/^[0-9a-f-]{36}$/i.test(uuid || '') || !/^[A-Za-z0-9_]{3,16}$/.test(username || '')) return res.status(400).json({ error: 'Invalid link payload' });
  db.prepare('DELETE FROM link_codes WHERE expires<? OR used=1').run(Date.now());
  db.prepare('INSERT INTO link_codes(code_hash,uuid,username,expires) VALUES(?,?,?,?)').run(sha(code), uuid, username, Date.now() + 5 * 60_000);
  res.json({ ok: true });
});
app.post('/api/plugin/player/sync', pluginOnly, (req, res) => {
  const { uuid, username, rank = 'Oyuncu', isOp, balance } = req.body || {};
  if (!/^[0-9a-f-]{36}$/i.test(uuid || '') || !/^[A-Za-z0-9_]{3,16}$/.test(username || '') || !Number.isFinite(balance) || balance < 0) return res.status(400).json({ error: 'Invalid player sync' });
  db.prepare(`INSERT INTO players(uuid,username,rank,balance,is_admin,last_seen) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(uuid) DO UPDATE SET username=excluded.username,rank=excluded.rank,balance=excluded.balance,is_admin=excluded.is_admin,last_seen=CURRENT_TIMESTAMP`)
    .run(uuid, username, String(rank).replace(/[\r\n]/g, '').slice(0, 50) || 'Oyuncu', balance, isOp ? 1 : 0);
  res.json({ ok: true });
});
app.get('/api/plugin/orders/next', pluginOnly, (_req, res) => {
  const tx = db.transaction(() => {
    const row = db.prepare(`SELECT o.id,o.uuid,p.command,o.price,pl.username FROM orders o JOIN products p ON p.id=o.product_id JOIN players pl ON pl.uuid=o.uuid WHERE o.status='pending' ORDER BY o.created_at LIMIT 1`).get();
    if (!row) return null;
    db.prepare("UPDATE orders SET status='processing' WHERE id=? AND status='pending'").run(row.id);
    return row;
  });
  res.json(tx());
});
app.post('/api/plugin/orders/result', pluginOnly, (req, res) => {
  const { id, success, message } = req.body || {};
  if (typeof id !== 'string' || typeof success !== 'boolean') return res.status(400).json({ error: 'Invalid result' });
  const status = success ? 'delivered' : 'failed';
  const result = db.prepare("UPDATE orders SET status=?,message=?,finished_at=CURRENT_TIMESTAMP WHERE id=? AND status='processing'").run(status, String(message || '').slice(0, 200), id);
  res.json({ ok: result.changes === 1 });
});

app.post('/api/link/claim', (req, res) => {
  const code = String(req.body?.code || '').toUpperCase().replace(/\s/g, '');
  if (!/^[A-HJ-NP-Z2-9]{8}$/.test(code)) return res.status(400).json({ error: '8 haneli bağlantı kodunu kontrol et.' });
  const tx = db.transaction(() => {
    const row = db.prepare('SELECT * FROM link_codes WHERE code_hash=? AND used=0 AND expires>?').get(sha(code), Date.now());
    if (!row) return null;
    db.prepare('UPDATE link_codes SET used=1 WHERE code_hash=?').run(sha(code));
    db.prepare(`INSERT INTO players(uuid,username) VALUES(?,?) ON CONFLICT(uuid) DO UPDATE SET username=excluded.username`).run(row.uuid, row.username);
    const token = randomToken();
    db.prepare('INSERT INTO sessions(token_hash,uuid,expires) VALUES(?,?,?)').run(sessionHash(token), row.uuid, Date.now() + 30 * 24 * 60 * 60_000);
    return { token, uuid: row.uuid };
  });
  const result = tx();
  if (!result) return res.status(400).json({ error: 'Kod geçersiz, kullanılmış veya süresi dolmuş. Oyunda /kodum yazıp yeni kod al.' });
  res.json({ token: result.token });
});
app.get('/api/me', auth, (req, res) => {
  const p = req.player;
  res.json({ uuid: p.uuid, username: p.username, rank: p.rank, balance: p.balance, isAdmin: !!p.is_admin,
    skin: `https://mc-heads.net/avatar/${encodeURIComponent(p.uuid)}/128`,
    orders: db.prepare('SELECT o.id,o.price,o.status,o.message,o.created_at,p.name product FROM orders o JOIN products p ON p.id=o.product_id WHERE o.uuid=? ORDER BY o.created_at DESC LIMIT 12').all(p.uuid) });
});
app.get('/api/store', (_req, res) => {
  res.json({ siteName: getSetting.get('site_name').value, accent: getSetting.get('accent').value,
    announcements: db.prepare('SELECT id,title,body FROM announcements WHERE active=1 ORDER BY id DESC LIMIT 5').all(),
    products: db.prepare('SELECT id,name,description,category,mode,price FROM products WHERE active=1 ORDER BY mode,category,id').all() });
});
app.post('/api/orders', auth, (req, res) => {
  const id = crypto.randomUUID();
  const productId = Number(req.body?.productId);
  const product = db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(productId);
  if (!product) return res.status(404).json({ error: 'Ürün bulunamadı.' });
  // Gerçek bakiye kontrolü ve tahsilat Vault ile Paper eklentisinde yapılır.
  db.prepare('INSERT INTO orders(id,uuid,product_id,price,status) VALUES(?,?,?,? ,\'pending\')').run(id, req.player.uuid, product.id, product.price);
  audit.run(req.player.uuid, 'order_created', `${product.name} / ${product.price}`);
  res.json({ ok: true, orderId: id, message: 'Sipariş kuyruğa alındı. Teslimat için sunucuda çevrimiçi ol.' });
});
app.get('/api/admin/overview', auth, admin, (_req, res) => {
  res.json({ players: db.prepare('SELECT COUNT(*) n FROM players').get().n, pending: db.prepare("SELECT COUNT(*) n FROM orders WHERE status IN ('pending','processing')").get().n,
    orders: db.prepare('SELECT o.id,o.uuid,pl.username,p.name product,o.price,o.status,o.message,o.created_at FROM orders o JOIN players pl ON pl.uuid=o.uuid JOIN products p ON p.id=o.product_id ORDER BY o.created_at DESC LIMIT 30').all(),
    products: db.prepare('SELECT * FROM products ORDER BY id DESC').all(),
    announcements: db.prepare('SELECT * FROM announcements ORDER BY id DESC').all(), siteName: getSetting.get('site_name').value, accent: getSetting.get('accent').value });
});
app.post('/api/admin/products', auth, admin, (req, res) => {
  const { name, description = '', category, mode, price, command, active = true } = req.body || {};
  if (!name || !['rank','item','other'].includes(category) || !['smp','boxpvp'].includes(mode) || !Number.isFinite(Number(price)) || Number(price) < 0 || Number(price) > 1e12 || !command || String(command).length > 240 || /[\r\n;]/.test(command)) return res.status(400).json({ error: 'Ürün alanlarını kontrol et.' });
  const result = db.prepare('INSERT INTO products(name,description,category,mode,price,command,active) VALUES(?,?,?,?,?,?,?)').run(String(name).slice(0,60), String(description).slice(0,240), category, mode, Number(price), String(command), active ? 1 : 0);
  audit.run(req.player.uuid, 'product_create', String(name)); res.json({ ok: true, id: result.lastInsertRowid });
});
app.put('/api/admin/products/:id', auth, admin, (req, res) => {
  const { name, description = '', category, mode, price, command, active } = req.body || {};
  if (!name || !['rank','item','other'].includes(category) || !['smp','boxpvp'].includes(mode) || !Number.isFinite(Number(price)) || Number(price) < 0 || !command || String(command).length > 240 || /[\r\n;]/.test(command)) return res.status(400).json({ error: 'Ürün alanlarını kontrol et.' });
  db.prepare('UPDATE products SET name=?,description=?,category=?,mode=?,price=?,command=?,active=? WHERE id=?').run(String(name).slice(0,60), String(description).slice(0,240), category, mode, Number(price), String(command), active ? 1 : 0, Number(req.params.id));
  audit.run(req.player.uuid, 'product_update', String(name)); res.json({ ok: true });
});
app.delete('/api/admin/products/:id', auth, admin, (req, res) => { db.prepare('DELETE FROM products WHERE id=?').run(Number(req.params.id)); audit.run(req.player.uuid, 'product_delete', req.params.id); res.json({ ok: true }); });
app.post('/api/admin/announcements', auth, admin, (req, res) => {
  const { title, body, active = true } = req.body || {};
  if (!title || !body) return res.status(400).json({ error: 'Başlık ve metin gerekli.' });
  db.prepare('INSERT INTO announcements(title,body,active) VALUES(?,?,?)').run(String(title).slice(0,80), String(body).slice(0,500), active ? 1 : 0);
  res.json({ ok: true });
});
app.delete('/api/admin/announcements/:id', auth, admin, (req, res) => { db.prepare('DELETE FROM announcements WHERE id=?').run(Number(req.params.id)); res.json({ ok: true }); });
app.put('/api/admin/settings', auth, admin, (req, res) => {
  const { siteName, accent } = req.body || {};
  if (siteName) setSetting.run('site_name', String(siteName).slice(0,40));
  if (accent && /^#[0-9a-fA-F]{6}$/.test(accent)) setSetting.run('accent', accent);
  audit.run(req.player.uuid, 'site_settings_update', 'theme'); res.json({ ok: true });
});

app.get('*', (req, res, next) => { if (req.path.startsWith('/api/')) return next(); res.sendFile(path.join(__dirname, 'public', 'index.html')); });
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'Sunucu hatası.' }); });
app.listen(PORT, '0.0.0.0', () => console.log(`SLIME WEB CONNECT ${PORT} portunda hazır.`));
