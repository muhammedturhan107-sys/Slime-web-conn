package live.slime.webconnect;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Pattern;

public final class SlimeWebConnect extends JavaPlugin {
    private static final String ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Pattern SAFE_COMMAND = Pattern.compile("^[a-zA-Z0-9_:/ .%+-]{1,240}$");
    private HttpClient http;
    private String baseUrl;
    private String secret;
    private Economy economy;

    @Override public void onEnable() {
        saveDefaultConfig();
        reloadSettings();
        http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
        setupEconomy();
        if (getCommand("kodum") != null) getCommand("kodum").setExecutor(this::onCodeCommand);
        if (getCommand("slimeweb") != null) getCommand("slimeweb").setExecutor(this::onAdminCommand);
        if (economy == null) getLogger().warning("Vault ekonomisi bulunamadı. Web satın alımları işlenmeyecek.");
        startWorker();
        getLogger().info("SLIME WEB CONNECT etkin. Web: " + baseUrl);
    }

    @Override public void onDisable() { Bukkit.getScheduler().cancelTasks(this); }

    private void reloadSettings() {
        reloadConfig();
        baseUrl = getConfig().getString("web-url", "http://localhost:3000").replaceAll("/+$", "");
        secret = getConfig().getString("plugin-secret", "");
        if (!baseUrl.startsWith("https://") && !baseUrl.matches("http://(localhost|127\\.0\\.0\\.1)(:[0-9]+)?")) getLogger().warning("Canlı kullanımda web-url HTTPS olmalı; HTTP üzerinden gizli anahtar açık ağda korunmaz.");
    }

    private void setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) economy = rsp.getProvider();
    }

    private boolean onCodeCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("§cBu komut sadece oyuncular içindir."); return true; }
        String code = makeCode();
        String body = "{\"code\":\"" + code + "\",\"uuid\":\"" + player.getUniqueId() + "\",\"username\":\"" + escape(player.getName()) + "\"}";
        asyncPost("/api/plugin/link/create", body).thenAccept(ok -> Bukkit.getScheduler().runTask(this, () -> {
            if (!player.isOnline()) return;
            if (ok) {
                player.sendMessage("§a§lSLIME WEB §8» §fBağlantı kodun: §e§l" + code);
                player.sendMessage("§7Bu kodu web sitesindeki bağlantı alanına yaz.");
                player.sendMessage("§cKod 5 dakika içinde geçersiz olur ve tek kullanımlıktır.");
            } else player.sendMessage("§cWeb servisine ulaşılamadı. Biraz sonra tekrar dene.");
        }));
        player.sendMessage("§7Tek kullanımlık kod hazırlanıyor...");
        return true;
    }

    private boolean onAdminCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("slimeweb.admin")) { sender.sendMessage("§cYetkin yok."); return true; }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadSettings(); setupEconomy(); sender.sendMessage("§aSLIME WEB CONNECT ayarları yenilendi."); return true;
        }
        sender.sendMessage("§e/slimeweb reload §7- Ayarları yeniler.");
        return true;
    }

    private void startWorker() {
        long interval = Math.max(40, getConfig().getLong("poll-interval-ticks", 100));
        new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) syncPlayer(p);
                if (economy != null) fetchOrders();
            }
        }.runTaskTimer(this, 40L, interval);
    }

    private void syncPlayer(Player p) {
        double balance = economy == null ? 0.0 : economy.getBalance(p);
        String rank = "Oyuncu";
        var team = p.getScoreboard().getEntryTeam(p.getName());
        if (team != null && team.getPrefix() != null && !team.getPrefix().isBlank()) {
            rank = team.getPrefix().replaceAll("§[0-9A-FK-ORa-fk-or]", "").trim();
        }
        String body = "{\"uuid\":\"" + p.getUniqueId() + "\",\"username\":\"" + escape(p.getName()) + "\",\"rank\":\"" + escape(rank) + "\",\"isOp\":" + p.isOp() + ",\"balance\":" + Math.max(0, balance) + "}";
        asyncPost("/api/plugin/player/sync", body);
    }

    private void fetchOrders() {
        asyncGet("/api/plugin/orders/next").thenAccept(json -> {
            if (json == null || json.equals("null") || json.isBlank()) return;
            // Backend yalnızca tek sipariş döndürür; alanlar güvenli JSON string parser ile alınır.
            String id = field(json, "id"), uuidText = field(json, "uuid"), username = field(json, "username"), cmd = field(json, "command");
            if (id == null || uuidText == null || username == null || cmd == null) return;
            UUID uuid;
            try { uuid = UUID.fromString(uuidText); } catch (IllegalArgumentException ex) { reportOrder(id, false, "Geçersiz oyuncu UUID"); return; }
            if (!SAFE_COMMAND.matcher(cmd).matches() || cmd.toLowerCase().startsWith("op ") || cmd.toLowerCase().startsWith("stop")) {
                reportOrder(id, false, "Ürün komutu güvenlik filtresini geçemedi"); return;
            }
            Bukkit.getScheduler().runTask(this, () -> {
                Player player = Bukkit.getPlayer(uuid);
                if (player == null || !player.isOnline()) { reportOrder(id, false, "Oyuncu çevrimiçi değil; tekrar deneyebilirsin"); return; }
                if (economy == null) { reportOrder(id, false, "Vault ekonomisi kullanılamıyor"); return; }
                double price;
                try { price = Double.parseDouble(field(json, "price")); } catch (Exception ex) { reportOrder(id, false, "Geçersiz fiyat"); return; }
                if (price < 0 || !Double.isFinite(price)) { reportOrder(id, false, "Geçersiz fiyat"); return; }
                if (economy.getBalance(player) < price) { reportOrder(id, false, "Yetersiz oyun bakiyesi"); return; }
                var result = economy.withdrawPlayer(player, price);
                if (!result.transactionSuccess()) { reportOrder(id, false, "Bakiye düşülemedi"); return; }
                String finalCommand = cmd.replace("%player%", player.getName()).replace("%uuid%", player.getUniqueId().toString());
                boolean dispatched = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCommand);
                if (dispatched) reportOrder(id, true, "Teslim edildi");
                else {
                    economy.depositPlayer(player, price);
                    reportOrder(id, false, "Teslim komutu başarısız; ücret iade edildi");
                }
                syncPlayer(player);
            });
        });
    }

    private void reportOrder(String id, boolean success, String message) {
        asyncPost("/api/plugin/orders/result", "{\"id\":\"" + escape(id) + "\",\"success\":" + success + ",\"message\":\"" + escape(message) + "\"}");
    }

    private CompletableFuture<Boolean> asyncPost(String path, String body) {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + path)).timeout(Duration.ofSeconds(8))
                    .header("Content-Type", "application/json").header("X-Slime-Secret", secret)
                    .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8)).build();
            return http.sendAsync(req, HttpResponse.BodyHandlers.ofString()).thenApply(r -> r.statusCode() >= 200 && r.statusCode() < 300).exceptionally(e -> false);
        } catch (Exception e) { return CompletableFuture.completedFuture(false); }
    }

    private CompletableFuture<String> asyncGet(String path) {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + path)).timeout(Duration.ofSeconds(8)).header("X-Slime-Secret", secret).GET().build();
            return http.sendAsync(req, HttpResponse.BodyHandlers.ofString()).thenApply(r -> r.statusCode() == 200 ? r.body() : null).exceptionally(e -> null);
        } catch (Exception e) { return CompletableFuture.completedFuture(null); }
    }

    private static String makeCode() { StringBuilder b = new StringBuilder(); for (int i = 0; i < 8; i++) b.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length()))); return b.toString(); }
    private static String escape(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", ""); }
    private static String field(String json, String key) {
        String needle = "\"" + key + "\":"; int i = json.indexOf(needle); if (i < 0) return null; i += needle.length();
        while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
        if (i >= json.length()) return null;
        if (json.charAt(i) == '"') { int end = i + 1; StringBuilder out = new StringBuilder(); boolean esc = false; for (; end < json.length(); end++) { char c = json.charAt(end); if (esc) { out.append(c); esc = false; } else if (c == '\\') esc = true; else if (c == '"') break; else out.append(c); } return out.toString(); }
        int end = i; while (end < json.length() && ",}".indexOf(json.charAt(end)) < 0) end++; return json.substring(i, end).trim();
    }
}
