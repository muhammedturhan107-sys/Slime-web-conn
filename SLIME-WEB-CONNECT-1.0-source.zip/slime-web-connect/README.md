# SLIME WEB CONNECT 1.0

Minecraft Java **1.21.11 / Paper** için hesap bağlama ve web mağazası projesi.

## Proje içeriği

- `plugin/`: Paper eklentisi kaynak kodu (`SLIME-WEB-CONNECT.jar` olarak derlenir).
- `website/`: Node.js + SQLite web sitesi, API ve yönetim paneli.
- `/kodum`: 5 dakika geçerli, tek kullanımlık 8 haneli bağlantı kodu üretir.
- SMP ve BOX PvP ürün listeleri.
- Oyuncu adı, UUID, Minecraft avatarı, scoreboard takım öneki üzerinden rütbe gösterimi, Vault bakiyesi ve sipariş geçmişi.
- Web mağazası siparişleri sunucu tarafında Vault ile tahsil edilir ve Paper konsol komutuyla teslim edilir.
- Yetkili paneli, oyuncunun gerçek OP durumunu Paper eklentisinin doğrulanmış sunucu isteğinden alır.

## Önemli gereksinimler

1. Java 21.
2. Paper 1.21.11.
3. Web API'nin erişebildiği bir sunucu/hosting (Node.js 20+).
4. Minecraft'ta ekonomi için **Vault + Vault uyumlu ekonomi eklentisi** (ör. EssentialsX Economy).
5. Rütbe ürünleri için LuckPerms; eşya ürünleri için ilgili sunucu komutları/eklenti.
6. İnternete açık gerçek kullanımda HTTPS alan adı ve güvenlik duvarı.

> Web uygulaması ücretsiz bir hosting'e kurulabilir; ancak ücretsiz hosting sağlayıcıları uykuya geçebilir veya SQLite kalıcı disk sağlamayabilir. Kalıcı disk ve sürekli çalışan servis seçilmelidir.

## 1) Web API kurulumu

`website` klasörüne gir:

```bash
cd website
cp .env.example .env
```

`.env` dosyasında `PLUGIN_SECRET`, `SESSION_SECRET` ve `SETUP_KEY` değerlerini birbirinden farklı, en az 40 karakterlik rastgele dizilerle değiştir. Örnek anahtar üretimi:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Aynı `PLUGIN_SECRET` değerini birazdan Paper eklentisinin `config.yml` dosyasına yaz. Ardından:

```bash
npm install
npm start
```

Yerel test adresi: `http://localhost:3000`

## 2) Paper eklentisi

`plugin` klasörünü Gradle 8.10+ ve Java 21 bulunan bir ortamda derle:

```bash
cd plugin
gradle build
```

Çıktı:

`plugin/build/libs/SLIME-WEB-CONNECT.jar`

JAR dosyasını Paper sunucusunun `plugins/` klasörüne koy ve sunucuyu bir kez başlat. Sonra:

`plugins/SLIME-WEB-CONNECT/config.yml`

Dosyasında `web-url` değerini web API adresinle, `plugin-secret` değerini web `.env` dosyasındaki `PLUGIN_SECRET` ile aynı yap. Ardından sunucuyu yeniden başlat veya `/slimeweb reload` kullan.

## 3) Gerekli Minecraft eklentileri

- Vault
- Vault destekli ekonomi eklentisi (ör. EssentialsX + EssentialsXSpawn değil, EssentialsX Economy)
- İsteğe bağlı: LuckPerms (rütbe ürünleri için)
- Ürün komutlarının kullandığı kasa/anahtar eklentisi (BOX PvP anahtarı örneği için)

Vault eklentisi yüklenmemişse SLIME WEB CONNECT başlatılamaz; Vault yüklü olsa bile ekonomi sağlayıcısı yoksa web siparişleri işlenmez. Bu, ücretsiz/gerçek para ile kontrolsüz sipariş açılmasını önlemek için bilinçli tasarımdır.

## 4) Oyuncu hesabı bağlama

1. Oyuncu sunucuya girer.
2. Oyunda `/kodum` yazar.
3. Sohbetteki 8 haneli kodu web sitesindeki **Oyuncu Girişi** alanına yazar.
4. Kod bir defa kullanılır ve 5 dakika sonra geçersiz olur.

Minecraft şifresi hiçbir noktada web sitesine girilmez.

## 5) Mağaza ürünleri

Ürün komutlarında kullanılabilen yer tutucular:

- `%player%` — oyuncunun Minecraft kullanıcı adı
- `%uuid%` — oyuncunun UUID değeri

Örnekler:

```text
lp user %player% parent set vip
give %player% diamond 10
```

Komutlar sunucu konsolundan çalışır. Ürün oluşturma erişimi yalnızca Paper tarafından OP olarak doğrulanan hesaplara verilir. Komutları yalnızca güvendiğin sunucu yöneticileri eklemelidir.

## Güvenlik notları

- Plugin secret tarayıcıya gönderilmez.
- Tek kullanımlık kodlar veritabanında SHA-256 özetiyle saklanır.
- Web oturumları rastgele bearer token ve SHA-256 özetiyle saklanır.
- Sipariş tahsilatı gerçek bakiye üzerinden Paper/Vault tarafında yapılır.
- OP durumu tarayıcıdan değil, eklentinin gizli anahtarla yaptığı sunucu isteğinden alınır.
- Canlıya almadan önce HTTPS kullan, güçlü gizli anahtarlar üret ve veritabanını yedekle.

## Şu anki kapsam / sonraki geliştirme

Bu sürüm temel mağaza, hesap bağlantısı, bakiye gösterimi, sipariş kuyruğu ve ürün/duyuru/tema yönetimini içerir. Otomatik oyuncu sayısı/MOTD sorgusu, web tabanlı LuckPerms grup editörü, detaylı kategori görselleri ve tam sipariş iade yönetimi sonraki sürümde eklenebilir.
